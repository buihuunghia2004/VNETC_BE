
export const NAVIGATION = {
  CHILD: 1,
  PARENT: 2
}

export const Cat_type = {
  PRODUCT: 1,
  NEW: 2
}
